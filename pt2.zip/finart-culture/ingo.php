<?php 
echo "bonjour";
phpinfo();
?>