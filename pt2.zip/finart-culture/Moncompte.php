<!doctype html>
<s?php session_start(); ?>
<html lang="fr">
	<head>
		<title> Finart Culture </title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="PTS2.css"/>
	</head>
	<?php include("header.php"); ?>
	<body>
	<div id="main">
		<h2> Inscrit toi !</h2>
			<form name="inscription" method="post" action="cible.php">
				<label for="nom">Entrez votre nom : </label>
				<input type="text" name="nom" id="nom"/>
				<label>Entrez votre prénom :<input type="text" name="prénom"/>
				Entrez votre date de naissance:<input type="date" name="datenaissance"/>
				Entrez votre adresse :<input type="text" name="adresse"/>
				Entrez votre code postale
			</form>

	</div>
	</body>
	<?php include("footer.php"); ?>
</html>