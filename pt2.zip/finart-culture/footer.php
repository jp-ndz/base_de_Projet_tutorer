<footer>
		<p class="Footertxt">Finart-culture est une plateforme de promotion culturelle et artistique. Une boutique en ligne est disponible.</p>
		<div class = "foot">
			<ul>
				<li class="menu-ml"><a href="MentionsLegales.php"> Mentions Légales </a></li>
				<li class="menu-cgv"><a href="CGV.php">CGV</a></li>
				<li class="menu-pc"><a href="PolitiqueConfidentialite.php">Politique de Confidentialité </a></li>
			</ul>
		</div>
		<div class="news">
			<form method="post">
				<p>Abonnez-vous à notre newsletter</p>
				<div>
					<label for="nom">Email:</label>
					<input type="text" id="nom" name="user_name">
				</div>
				<p class="newsp2"><input type="checkbox" name="pc" required class ="tnp-private"/>En continuant vous acceptez la politique de confidentialité</p>
				<div class="button">
					<button>S'abonner</button>
				</div>
			</form>
			
		</div>
		<div class="reseaux">
			<p>Suivez-nous sur les réseaux</p>
			<p><a href="https://facebook.com"><img src="fb.png" class="fb" alt="logo facebook"></a>
			<a href="https://instagram.com"><img src="insta.png" class="insta" alt="logo instagram"></a></p>
		</div>
</footer>