<header>
		<a href="Accueil.html"><img id="Logo" src="logo.png" alt="Logo du Projet"></a>
		<div class="LD">
			<ul>
				<li class="lpt"><a href="Démarrervotreprojet.php">Lancer  un projet</a></li>
				<li class ="fpt"><a href = " financerunprjet.php">Financer un projet</a></li>
				<li class="sct"><a href="Moncompte.php">Se connecter</a></li>
				<li class="panier"><a href = "panier.php"><img id="panier" src="panier.png" alt ="logo menu deroulant"></a></li> 
			</ul>
		</div>
		<?php include("menu.php"); ?>
			<div class="dropdown">
				<button class="drpbutt"><img src="loupe.jpg" class="loupe" alt="Recherche"></button>
					<div class="drpdwn-content">
						<input type="search" id="maRecherche" name="q"
						placeholder="Rechercher sur le site…"/>
						<button>Rechercher</button>
					</div>
		</div>
</header>